const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const routeHandler = require('./routes');

var port = process.env.PORT || 3333;


app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: false }))


app.use('/user', routeHandler.user_routes);

app.listen(port,()=> {
    console.log("Listening on 3333");
});