const userRoute = require('./user_routes');

module.exports = {
    user_route: userRoute
}