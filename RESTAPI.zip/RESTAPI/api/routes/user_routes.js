const express = require('express');
const router = express.Router();

const services = require('../handler/app');


router.post('/login', services.loginuser);

module.exports = router;