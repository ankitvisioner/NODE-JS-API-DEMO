

module.exports.loginuser = async(req,res) => {
    res.send("in login user");
}
